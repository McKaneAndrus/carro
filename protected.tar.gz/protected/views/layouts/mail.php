<html>
<head>
	<meta content="text/html; charset=UTF-8" http-equiv="content-type">
</head>
<table cellspacing="0" cellpadding="10" style="color:#666;font:13px Arial;line-height:1.4em;width:100%;">
	<tbody>
		<tr>
            <td style="color:#4D90FE;font-size:22px;border-bottom: 2px solid #EC1D25;">
				<a style="outline : none;" href="http://achacarro.com/"><img style="border : 0" alt="achacarro.com" src="achacarro_mail_logo_sm.png" /></a>
            </td>
		</tr>
		<tr>
            <td>
				<?php echo $content ?>
            </td>
		</tr>
		<tr>
            <td style="padding:10px 20px;text-align:center;border-top:solid 1px #dfdfdf">
				<a style="outline : none" href="http://www.achacarro.com/"><img style="border : 0" alt="achacarro.com" src="achacarro_mail_logo.png" /></a>
			</td>
		</tr>
		<tr>
            <td style="padding:5px 20px;text-align:center;">
				Copyright (c) 2014 Achacarro
			</td>
		</tr>
	
	</tbody>
</table>
</body>
</html>
