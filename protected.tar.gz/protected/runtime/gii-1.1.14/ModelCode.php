<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => 'br_',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '0',
  'commentsAsLabels' => '0',
);
