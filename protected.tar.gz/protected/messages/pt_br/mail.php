<?php
// pt_br langange translations for thank you mail
// format is 'English' => 'Portuguese'
// Remeber strings must be exact to match a translation!
// v1.0.0 Mail translations 
// begat : 05/02/2014
//

return array(

	'Achacarro Confirmation Email' => 'Achacarro Confirmação de E-mail',
	'Customer Support' => 'Suporte ao Cliente',
	'Your dealer will contact you by phone or email in the next 24 hours. Please email us if you don’t hear from them or need further assistance.' =>'Uma das nossas concessionárias entrará em contato com você por telefone ou email nas próximas 24 horas. Por favor, nos envie um email caso você não seja contatado ou tenha alguma dúvida.',

	'Dear' => 'Prezado',
	'from' => 'da',
	
	'We received your request for a price quote on a' => 'Nós recebemos seu pedido para cotação de um',
	'Below is a list of your selected dealers' => 'Abaixo está uma lista de seus revendedores selecionados',
	'Unfortunately, we could not find a participating dealer near you.' => 'Nesse momento não conseuimos localizar uma concessionária participante próxima.',
	'Our apologies for the inconvenience,' => 'Pedimos desculpas pelo inconveniente',
	'We appreciate your business' => 'Nós apreciamos o seu negócio,',
);
?>

